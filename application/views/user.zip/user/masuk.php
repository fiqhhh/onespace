<!DOCTYPE html>
<html>

<head>
    <title><?= $title; ?></title>
    <link href="<?= base_url('assets/template/dist/css/style.css'); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('assets/template/vendors/jquery-toggles/css/toggles.css'); ?>" rel="stylesheet" type="text/css">
    <link href="<?= base_url('assets/template/vendors/jquery-toggles/css/themes/toggles-light.css'); ?>" rel="stylesheet" type="text/css">
    <script src="<?= base_url('assets/loginQrcode/') ?>scanner/css/style.css"></script>
    <script src="<?= base_url('assets/loginQrcode/') ?>js/jquery-3.4.1.min.js"></script>
    <script src="<?= base_url('assets/loginQrcode/') ?>scanner/vendor/modernizr/modernizr.js"></script>
    <script src="<?= base_url('assets/loginQrcode/') ?>scanner/vendor/vue/vue.min.js"></script>
</head>

<body>

    <!-- Preloader -->
    <div class="preloader-it">
        <div class="loader-pendulums"></div>
    </div>
    <!-- /Preloader -->

    <div class="hk-wrapper">

        <!-- Main Content -->
        <div class="hk-pg-wrapper hk-auth-wrapper">
            <header class="d-flex justify-content-end align-items-center">
                <div class="btn-group btn-group-sm">
                    <a href="#" class="btn btn-outline-secondary"><i class="icons-size" data-feather="help-circle"></i> Bantuan</a>
                </div>
            </header>
            <div class="container-fluid">
                <div class="auth-form-wrap pt-xl-0 pt-70">
                    <div class="auth-form w-xl-40 w-lg-55 w-sm-75 w-100">
                        <a class="auth-brand text-center d-block mb-20" href="#">
                            <img class="brand-img" src="dist/img/logo-light.png" alt="OneSpaceLogo" />
                        </a>
                        <form action="<?= base_url('masuk/') ?>" method="post" id="myForm">
                            <h1 class="display-4 text-center mb-10">One Space</h1>
                            <p class="text-center mb-30">Masuk dengan akun anda dan belajar yang bener!</p>


                            <?= Flasher::flash(); ?>
                            <div id="app" class="col-md-12 justify-content-center text-center">
                                <div v-for="camera in cameras" id="id_work_days">
                                    <span v-if="camera.id == activeCameraId" :title="formatName(camera.name)" class="active">
                                        <input type="checkbox" class="align-middle mr-1" checked> {{ formatName(camera.name) }}
                                    </span>
                                    <span v-if="camera.id != activeCameraId" :title="formatName(camera.name)">
                                        <a @click.stop="selectCamera(camera)">
                                            <input type="checkbox" class="align-middle mr-1">{{ formatName(camera.name) }}
                                        </a>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <select class="form-control custom-select" name="privillege" id="privillege" onChange="tampilInput(this)">
                                    <option selected="" disabled="">Masuk Sebagai</option>
                                    <option value="1">Guru</option>
                                    <option value="2">Murid</option>
                                    <option value="3">Orang Tua</option>
                                </select>
                                <?= form_error('privillege', '<small class="text-danger">', '</small>'); ?>
                            </div>
                            <div class="form-group" id="muridNisn" style="display:block;">
                                <video id="preview"></video>
                                <input class="form-control" id="code" type="text" name="nisn_murid" placeholder="Masukan NISN">
                            </div>
                            <div class="form-group" id="guruNip" style="display:block;">
                                <video id="preview1"></video>
                                <input class="form-control" id="code1" type="text" name="nip_guru" placeholder="Masukan NIP">
                            </div>
                            <div class="form-group" id="ortuNisn" style="display:block;">
                                <video id="preview2"></video>
                                <input class="form-control" id="code2" type="text" name="nisn_anak" placeholder="Masukan NISN Anak">
                            </div>
                            <div class="form-group">
                                <button class="btn btn-primary btn-block" type="submit"><i class="icons-size" data-feather="log-in"></i> Submit</button>
                            </div>

                            <div class="custom-control custom-checkbox mb-25">
                                <input class="custom-control-input" id="same-address" type="checkbox" checked>
                                <label class="custom-control-label font-14" for="same-address">Keep me logged in</label>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <!-- /HK Wrapper -->

    <!-- JavaScript -->

    <script src="<?= base_url('assets/template/vendors/jquery/dist/jquery.min.js'); ?>"></script>
    <script src="<?= base_url('assets/template/vendors/popper.js/dist/umd/popper.min.js'); ?>"></script>
    <script src="<?= base_url('assets/template/vendors/bootstrap/dist/js/bootstrap.min.js'); ?>"></script>
    <script src="<?= base_url('assets/template/dist/js/jquery.slimscroll.js'); ?>"></script>
    <script src="<?= base_url('assets/template/dist/js/dropdown-bootstrap-extended.js'); ?>"></script>
    <script src="<?= base_url('assets/template/dist/js/feather.min.js'); ?>"></script>
    <script src="<?= base_url('assets/template/dist/js/init.js'); ?>"></script>

    <script type="text/javascript">
        function tampilInput(value) {

            var st = $("#privillege").val();

            if (st == "1") {
                document.getElementById("guruNip").style.display = 'block';
                document.getElementById("muridNisn").style.display = 'none';
                document.getElementById("ortuNisn").style.display = 'none';

            } else if (st == "2") {
                document.getElementById("guruNip").style.display = 'none';
                document.getElementById("muridNisn").style.display = 'block';
                document.getElementById("ortuNisn").style.display = 'none';
            } else if (st == "3") {
                document.getElementById("guruNip").style.display = 'none';
                document.getElementById("muridNisn").style.display = 'none';
                document.getElementById("ortuNisn").style.display = 'block';
            }
        }
    </script>
    <script src="<?= base_url('assets/loginQrcode/') ?>scanner/js/app.js"></script>
    <script src="<?= base_url('assets/loginQrcode/') ?>scanner/vendor/instascan/instascan.min.js"></script>
    <script id="scanner" src="<?= base_url('assets/loginQrcode/') ?>scanner/js/scanner.js"></script>

</body>

</html>